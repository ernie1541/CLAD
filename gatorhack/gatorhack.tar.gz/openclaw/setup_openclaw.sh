#!/usr/bin/env bash
# Installs the three Traveler bots into OpenClaw:
#   cad-lead-engineer (gemma4:26b), cad-sub-engineer (gemma4:e4b), cad-machinist (gemma4:26b)
# Copies each agent workspace + the cadflow skill, pulls the Gemma models, and prints the config to merge.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
OC="${OPENCLAW_HOME:-$HOME/.openclaw}"

echo "Installing Traveler agents into $OC"
for agent in cad-lead-engineer cad-sub-engineer cad-machinist; do
  ws="$OC/workspace-$agent"
  mkdir -p "$ws/skills"
  for f in AGENTS.md SOUL.md IDENTITY.md TOOLS.md; do
    if [ -f "$ws/$f" ] && ! cmp -s "$HERE/agents/$agent/$f" "$ws/$f"; then
      cp "$ws/$f" "$ws/$f.bak"
      echo "  backed up existing $ws/$f → $f.bak"
    fi
    cp "$HERE/agents/$agent/$f" "$ws/$f"
  done
  rm -rf "$ws/skills/cadflow"
  cp -R "$HERE/skills/cadflow" "$ws/skills/cadflow"
  echo "  ✓ $agent → $ws"
done

if command -v ollama >/dev/null 2>&1; then
  for m in gemma4:26b gemma4:e4b; do
    if ollama list | awk '{print $1}' | grep -qx "$m"; then
      echo "  ✓ $m already pulled"
    else
      printf "Pull %s now? It is a large download. [y/N] " "$m"
      read -r yn
      case "$yn" in [Yy]*) ollama pull "$m" ;; *) echo "  skipped (run: ollama pull $m)";; esac
    fi
  done
else
  echo "  ! Ollama not found. Install it from https://ollama.com, then: ollama pull gemma4:26b && ollama pull gemma4:e4b"
fi

cat <<EOF

Next steps
1. Merge this into $OC/openclaw.json (pick your own token):
     $HERE/openclaw.fragment.json5
2. Restart the gateway:   openclaw gateway restart     (then check: openclaw doctor)
3. Tell Traveler the token: add  OPENCLAW_GATEWAY_TOKEN=<your token>  to ../.env
   (or paste it on Traveler's Dev page). Traveler auto-detects the gateway on 127.0.0.1:18789.
4. Optional: chat with the lead engineer on any OpenClaw channel. It uses the cadflow skill to run
   jobs through Traveler and relays every approval to you.
EOF
